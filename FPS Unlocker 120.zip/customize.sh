# Module version
MODVER=$(grep_prop version $TMPDIR/module.prop)

ui_print " "
ui_print "*********************************"
ui_print "        $MODNAME $MODVER         "
ui_print "*********************************"
ui_print " "
ui_print "- Enjoy 120fps in PUBG and CoD"
ui_print " "
